// לוח האלופים של מילעל — פונקציית Netlify עם אחסון Blobs
// GET  /api/board?date=2026-09-14   → { entries: [...] }
// POST /api/board  { date, name, turns, max, hints, ms, won }
import { getStore } from "@netlify/blobs";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const MAX_PLAYERS_PER_DAY = 200;

const clampInt = (v, lo, hi, dflt) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : dflt;
};

export default async (req) => {
  const store = getStore("milel-board");
  const url = new URL(req.url);

  if (req.method === "GET") {
    const date = url.searchParams.get("date") || "";
    if (!DATE_RE.test(date)) return Response.json({ entries: [] });
    const day = (await store.get(date, { type: "json" })) || {};
    return Response.json({ entries: Object.values(day) }, {
      headers: { "cache-control": "no-store" }
    });
  }

  if (req.method === "POST") {
    let body;
    try { body = await req.json(); } catch { return new Response("bad json", { status: 400 }); }

    const date = String(body.date || "");
    const name = String(body.name || "").trim().slice(0, 24);
    if (!DATE_RE.test(date) || !name) return new Response("bad request", { status: 400 });

    const entry = {
      name,
      won: !!body.won,
      turns: clampInt(body.turns, 1, 30, 30),
      max: clampInt(body.max, 1, 30, 8),
      hints: clampInt(body.hints, 0, 30, 0),
      ms: clampInt(body.ms, 0, 24 * 60 * 60 * 1000, 0),
      at: new Date().toISOString()
    };

    // כתיבה בטוחה: אם מישהו אחר סיים בדיוק באותו רגע, קוראים שוב ומנסים שוב
    for (let attempt = 0; attempt < 4; attempt++) {
      const cur = await store.getWithMetadata(date, { type: "json" });
      const day = (cur && cur.data) || {};
      if (!(name in day) && Object.keys(day).length >= MAX_PLAYERS_PER_DAY) {
        return new Response("board full", { status: 429 });
      }
      day[name] = entry;
      const opts = cur && cur.etag ? { onlyIfMatch: cur.etag } : { onlyIfNew: true };
      let res;
      try {
        res = await store.setJSON(date, day, opts);
      } catch {
        await store.setJSON(date, day);           // גיבוי אם התנאי אינו נתמך
        return Response.json({ ok: true, entries: Object.values(day) });
      }
      if (!res || res.modified !== false) {
        return Response.json({ ok: true, entries: Object.values(day) });
      }
    }
    return new Response("busy", { status: 409 });
  }

  return new Response("method not allowed", { status: 405 });
};

export const config = { path: "/api/board" };
